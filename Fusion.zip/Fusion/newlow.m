function [I] = newlow(I1,I2)
% This procedure is low frequency fusion rule, sum of three graphs /3 
[m,n]=size(I1);
I=zeros(m,n);

for i=1:m
    for j=1:n
        I(i,j)=(I1(i,j)+I2(i,j))/2;
    end
end
