function [low1,low2,hight1,hight2] = load_NSCT(im1,im2)
[im1,t1]=wiener2(im1,[5,5]);[im2,t2]=wiener2(im2,[5 ,5]);
%% NSCT demcompose
[m,n]=size(im1);
coeffs1=eaxm1(im1);coeffs2=eaxm1(im2);% eam1 is  program of demcompose by NSCT
low1=coeffs1{1,1};low2=coeffs2{1,1}; % The low frequencies after NSC of each image were assigned to lowi
%%
hight1=[];hight2=[];
parfor i=2:3
    B1=coeffs1{1,i};
    B1=cell2mat(B1);
    hight1=[hight1;B1];
    B2=coeffs2{1,i};
    B2=cell2mat(B2);
    hight2=[hight2;B2];
end
%% Segment the high frequency signal
hight1= Divide_into_block(hight1,m,n);hight2= Divide_into_block(hight2,m,n);
end