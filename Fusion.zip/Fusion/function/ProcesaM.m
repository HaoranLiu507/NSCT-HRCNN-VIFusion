function varargout = ProcesaM(varargin)
% PROCESAM M-file for ProcesaM.fig
%      PROCESAM, by itself, creates a new PROCESAM or raises the existing
%      singleton*.
%
%      H = PROCESAM returns the handle to a new PROCESAM or the handle to
%      the existing singleton*.
%
%      PROCESAM('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PROCESAM.M with the given input arguments.
%
%      PROCESAM('Property','Value',...) creates a new PROCESAM or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ProcesaM_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ProcesaM_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ProcesaM

% Last Modified by GUIDE v2.5 01-Feb-2010 13:56:15

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ProcesaM_OpeningFcn, ...
                   'gui_OutputFcn',  @ProcesaM_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ProcesaM is made visible.
function ProcesaM_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ProcesaM (see VARARGIN)

% Choose default command line output for ProcesaM
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ProcesaM wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ProcesaM_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in BotonCargar.
function BotonCargar_Callback(hObject, eventdata, handles)
% hObject    handle to BotonCargar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%OPEN A FILE DIALOG
[filename,pathname] = uigetfile({'*.bmp';'*.pgm';'*.png';'*.jpg'},...
'UIGETFILE TITLE',...
100,100);

%STORE THE FILE NAME
handles.nombreArchivo=filename;

%READ THE FILE AND DISPLAY IT
handles.im=(imread([pathname,filename]));
axes(handles.Original);
handles.hIm=imshow(handles.im);
handles.imrec=zeros( size(handles.im) );

% Update handles structure
guidata(hObject, handles);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%
%%%%%%%%%% THIS IS THE MAIN FUNCTION IT CAN RUN STAND ALONE 
%%%%%%%%%% IF YOU WANT, JUST COPY AND PASTE, 
%%%%%%%%%% IT REQUIRES THE INPUT IMAGE IN: handles.im
%%%%%%%%%% THE IMAGE HAS TO BE A GRAY 256 IMAGE, OF SIZE POWER OF TWO
%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% --- Executes on button press in BotonProcesar.
function BotonProcesar_Callback(hObject, eventdata, handles)
% hObject    handle to BotonProcesar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
t = clock;
POSITION = [250 380 200 20]; % Position of uiwaitbar in pixels.
H = uiwaitbar(POSITION);
 
 
uiwaitbar(H,0.01); 
drawnow

% TRANSFORM PARAMETERS 
nlevels = [1, 1, 3, 2] ;        % Decomposition level
pfilter = 'maxflat' ;              % Pyramidal filter
dfilter = 'dmaxflat7' ;              % Directional filter

% TRANSFORM: Nonsubsampled Contourlet decomposition
coeffs = nsctdec( double(handles.im), nlevels, dfilter, pfilter );
uiwaitbar(H,0.37);
drawnow
%DEFINES NUMBER  OF DIRECTIONS TO USE PER LEVEL
nDirecciones=[0 2 2 8 4];
% Tmax <-STORE THRESHOLD FOR ALL LEVELS 
Tmax=0;
NumNiveles=4;
disp(['time elapsed:',num2str(etime(clock, t)),'Seg']);
disp('Obtain edges'); t = clock;
%'for' TO PROCESS ALL LEVELS
for Nivel=[2,3,4,5]%2:(NumNiveles+1)

   %PROCESS LEVEL 
   
   
  for i=1:nDirecciones(Nivel)
    %figure
    %FINDS LOCAL THRESHOLD 
    xx=coeffs{Nivel}{i};
    Var= std2(xx); %Standard deviation of matrix elements
    T{Nivel}{i}=(3*Var); 
    
    %APLY OPERATOR TO FIND EDGES
    Bordes{Nivel}{i}=edge(coeffs{Nivel}{i},'prewitt',T{Nivel}{i});
    %imshow(bordes{i},[])
    %title( ['Bordes nivel 4, ',num2str(i)] ) ;
    
    % THRESHOLD
    if( T{Nivel}{i}>Tmax  )
        Tmax=T{Nivel}{i};
    
    end

  end
end

uiwaitbar(H,0.5);
drawnow
cof=coeffs;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%  SECOND STEP MODIFY SUBBANDS  %%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Modificando');
for Nivel=[2,3,4,5]%2:(NumNiveles+1)

   %PROCESSS LEVEL
  for i=1:nDirecciones(Nivel)

    
    
    
    Var= std2(coeffs{Nivel}{i});
    
    %OBTAIN  GLOBAL GAIN
    %g=(Tmax*Var*4)/T{Nivel}{i};
    g=(1/Var*4);
    
    [X,Y]=size( coeffs{Nivel}{i} );
    
    for x=1:X
        for y=1:Y
            tempo=Bordes{Nivel}{i};
            if( tempo(x,y)==1)
                cof{Nivel}{i}(x,y)=coeffs{Nivel}{i}(x,y)*g;
            else                         %3
                cof{Nivel}{i}(x,y)=(1/Var*3)*coeffs{Nivel}{i}(x,y);
            end
        end
    end
  end
end

uiwaitbar(H,0.63);
drawnow
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%   RECONSTRUCT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

disp(['time elapsed :',num2str(etime(clock, t)),'Seg']);
disp('reconstruct');t = clock;
imrec = nsctrec( cof, dfilter, pfilter ) ;
uiwaitbar(H,0.99);
disp(['time elapsed:',num2str(etime(clock, t)),'Seg']);
disp('Showing') ;



axes(handles.ImProcesada);
imagesc( imrec,[0, 255]  );
colormap(gray);
uiwaitbar(H,1.0);


handles.imrec=uint8(round(imrec));


% Update handles structure
guidata(hObject, handles);


function h = uiwaitbar(varargin)
%uiwaitbar: A waitbar that can be embedded in a GUI figure.
% Syntax:
% POSITION = [20 20 200 20]; % Position of uiwaitbar in pixels.
% H = uiwaitbar(POSITION);
% for i = 1:100
% uiwaitbar(H,i/100)
% end
 
% written by Doug Schwarz, 11 December 2008
 
if ishandle(varargin{1})
    ax = varargin{1};
    value = varargin{2};
    p = get(ax,'Child');
    x = get(p,'XData');
    x(3:4) = value;
    set(p,'XData',x)
    return
end
 
pos = varargin{1};
bg_color = 'w';
fg_color = 'b';
h = axes('Units','pixels',...
    'Position',pos,...
    'XLim',[0 1],'YLim',[0 1],...
    'XTick',[],'YTick',[],...
    'Color',bg_color,...
    'XColor',bg_color,'YColor',bg_color);
patch([0 0 0 0],[0 1 1 0],fg_color,...
    'Parent',h,...
    'EdgeColor','none',...
    'EraseMode','none');



% --- Executes on button press in SaveResult.
function SaveResult_Callback(hObject, eventdata, handles)
% hObject    handle to SaveResult (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename,pathname] =uiputfile({'*.pgm';'*.bmp';'*.png';'*.jpg'},'Save result to file');
imwrite(handles.imrec,[pathname,filename]);
