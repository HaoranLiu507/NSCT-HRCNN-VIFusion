function [IM] = Coefficient_fusion(im1,im2,im3)
%�˳���ΪС���ںϹ��� ˭��ȡ��
[I,J,K]=size(im1);IM=zeros(I,J,K);
parfor k=1:K
    for j=1:J
        for i=1:I
            if abs(im1(i,j,k))>=abs(im2(i,j,k))
            if abs(im1(i,j,k))>=abs(im3(i,j,k))
                IM(i,j,k)=im1(i,j,k);
            end
            end
            if abs(im2(i,j,k))>=abs(im1(i,j,k))
            if abs(im2(i,j,k))>=abs(im3(i,j,k))
                IM(i,j,k)=im2(i,j,k);
            end
            end
            if abs(im3(i,j,k))>=abs(im1(i,j,k))
            if abs(im3(i,j,k))>=abs(im2(i,j,k))
                IM(i,j,k)=im3(i,j,k);
            end
            end
        end
    end
end
            
  

