clc;clear
%% This program is the main program of wavelet fusion

%% Adding a path
addpath("..\function\");
addpath("..\Tool_function\");
addpath("..\Image\");
addpath('Functions\')
addpath('mex\');
im1= imread('Frogtoe4_absorption.tif');
im1= rgb2gray(im1(:,:,1:3)); 
im2= imread('Frogtoe4_refraction.tif');
im2= rgb2gray(im2(:,:,1:3)); 
im3= imread('Frogtoe4_scattering.tif');
im3= rgb2gray(im3(:,:,1:3));
%%  Cut the original image 800��800
im1=im1(25:671,110:756);im2=im2(25:671,110:756);im3=im3(25:671,110:756);
%% Re-crop the region
long1 =200;long2=500;long3 =50;long4=600;%figure.4
im1=im1(long3:long4,long1:long2);im2=im2(long3:long4,long1:long2);im3=im3(long3:long4,long1:long2);
%
%
% long1 = 50;long2=577;long3 = 114;long4 = 525; %figure.2
% im1=im1(long1:long2,long3:long4);im2=im2(long1:long2,long3:long4);im3=im3(long1:long2,long3:long4);

%% Choosing wavelets
wnames = {'db1','db4'};
perserve_l2_norm = true; % Selective filtering
nddwt = nd_dwt_2D(wnames,size(im1),'pres_l2_norm',perserve_l2_norm);
%% The graph wavelet decomposition program, the last level for the decomposition level
Im1=xiaobo(im1,4);Im2=xiaobo(im2,4);Im3=xiaobo(im3,4);
[i,j,k]=size(Im1);LF=zeros(i,j,k);
low1=Im1(:,:,1);low2=Im2(:,:,1);low3=Im3(:,:,1); % Assign a low frequency signal to a lowi
Im1(:,:,1)=[];Im2(:,:,1)=[];Im3(:,:,1)=[];
Low1=xiaobo(low1,5);Low2=xiaobo(low2,5);Low3=xiaobo(low3,5);% The low-frequency signal is then decomposed into wavelet
HIGHT=Coefficient_fusion(Im1,Im2,Im3);LOW=Coefficient_fusion(Low1,Low2,Low3); %The wavelet fusion rule takes the larger one
LOW = nddwt.rec(LOW);
LF(:,:,1)=LOW;
for I=1:k-1
    LF(:,:,I+1)=HIGHT(:,:,I);
end % This code is to let the high and low frequency matrix synthesis matrix


%% Inverse wavelet, high and low frequency synthesis into a picture
x_recon = nddwt.rec(LF); 
H=x_recon; 
IM1=im1;IM2=(im2);IM3=(im3);
im1=mat2gray(im1);im2=mat2gray(im2);im3=mat2gray(im3);H=mat2gray(((H)));%��һ��

H_uint8=im2uint8(H); %im2uint8
IDEX=[];a=[];b=[];
A=[];B=[];
%% computed index
[qa,ga]=ES(im1,H);[qb,gb]=ES(im2,H);[qc,gc]=ES(im3,H); edge_strength=ESfusion(qa,ga,qb,gb,qc,gc);%edge strength
Entropy=entropy(H);
Standard_deviation=SD(H);
Spatial_frequency=SpatialFrequency(H_uint8);
FMI=FeatureMutualInformation(im1,im2,im3,H,'edge');Feature_Mutual_Information=(FMI(1)+FMI(2)+FMI(3))/3;
f1=mutual_information((IM1),(H_uint8));f2=mutual_information((IM2),(H_uint8));f3=mutual_information((IM3),(H_uint8));Fusion_Factor=f1+f2+f3;
ssim1=SSIM(im1, H);ssim2=SSIM(im2, H);ssim3=SSIM(im3, H);structual_similarity_index_measure=(ssim1+ssim2+ssim3)/3;
FSIM1=FSIM(im1, H);FSIM2=FSIM(im2, H);FSIM3=FSIM(im3, H);Feature_similarity_index_measure=(FSIM1+FSIM2+FSIM3)/3;
idex=[edge_strength;Entropy;Standard_deviation;Spatial_frequency;Feature_Mutual_Information;Fusion_Factor;structual_similarity_index_measure;Feature_similarity_index_measure];
idex=double(idex); idex=idex';
%% show
    xlswrite("..\idex_fig4.xlsx",idex,'sheet1',"B4:I4"); %save the index 
    imwrite(H,'wavelet4.jpg','jpg');% save the figure
    IDEX=[IDEX;idex];
    imshow(H)