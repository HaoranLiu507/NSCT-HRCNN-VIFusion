function I=ContrastAdjustment(II,a,b)
I=1./(1+exp(a*(b-II(:,:))));
end