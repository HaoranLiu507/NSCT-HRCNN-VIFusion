function sd = SD(I)
[m,n]=size(I);
I=double(I);
miu=mean(mean(I));sum=0;
for i=1:m
    for j=1:n
        p=(I(i,j)-miu)^2;
        sum=sum+p;
    end
end
sd=sqrt(sum/(m*n));
 