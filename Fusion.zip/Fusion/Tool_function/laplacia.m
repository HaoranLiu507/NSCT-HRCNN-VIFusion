function  g  = laplacia(f2)
w=fspecial('laplacian',0);
g2=imfilter(f2,w,'replicate');
g=f2-g2;
 
  