function a = FeatureMutualInformation(im1, im2,im3, imf,feature)
F1=fmi(im1,im2,imf,feature,3);
F2=fmi(im1,im3,imf,feature,3);
F3=fmi(im2,im3,imf,feature,3);
a=[F1,F2,F3];