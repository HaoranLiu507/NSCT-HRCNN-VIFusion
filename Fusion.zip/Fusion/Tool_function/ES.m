function  [QA,gA]=ES(im1,im2)
kapag=0.9994;kapaa=0.9879;kg=1;ka=-22;sigamag=0.5;sigamaa=0.8;L=1;
[~,~,Gv,Gh]  = edge(im1,'sobel');
aA=atan(Gv./Gh);gA=sqrt(Gv.^2+Gh.^2);
aA(find(isnan(aA)==1)) = 0;
[~, ~,gv,gh]  = edge(im2,'sobel');
aF=atan(gv./gh);gF=sqrt(gv.^2+gh.^2);
aF(find(isnan(aF)==1)) = 0;
[m,n]=size(aA);Gaf=zeros(m,n);Aaf=Gaf;Qg=Gaf;Qa=Gaf;QA=Gaf;
for i=1:m
    for j=1:n
        if gA(i,j)>gF(i,j)
            Gaf(i,j)=gF(i,j)./gA(i,j);
        else
            Gaf(i,j)=gA(i,j)./gF(i,j);
        end
        Aaf(i,j)=1-(abs(aA(i,j)-aF(i,j))/(pi/2));
        Qg(i,j)=kapag/(1+exp(kg.*(Gaf(i,j)-sigamag)));
        Qa(i,j)=kapaa/(1+exp(ka.*(Aaf(i,j)-sigamaa)));
    end
end
QA=Qg.*Qa;
 
 
 