function sum=ESfusion(qa,ga,qb,gb,qc,gc)
[m,n]=size(qa);L=1;
wa=ga.^L;wb=gb.^L;wc=gc.^L;sumA=0;sumB=0;sum=0;
for i=1:m
   for j=1:n
       A=(qa(i,j).*wa(i,j)+qb(i,j).*wb(m,n)+qc(i,j).*wc(i,j));
       B=(wa(i,j)+wb(i,j)+wc(i,j));
       sumA=sumA+A;
       sumB=sumB+B;
    end
end
sum=sumA/sumB;