function [imrec] = LSF(low1,low2,hight1,hight2,dynamic_param,static_param)
% This program is to combine high and low frequency inverse NSCT into a graph
[m,n]=size(low1);
low=newlow(low1,low2);% Low frequency fusion program lowi is the frequency
[H1,H2]=newfusion_HRCNN(hight1,hight2,m,n,dynamic_param,static_param);
H=cell(1,3);
H{1,1}=low;H{1,2}=H1;H{1,3}=H2;
pfilter = '9-7' ;              % Pyramidal filter % pyramidal filter
dfilter = 'pkva' ;              % Directional filter % directional filter
imrec = nsctrec( H, dfilter, pfilter ) ;% inverse NSCT function into a graph, the function is located in the NSCT folder
end

