function [G1,G2] = newfusion_HRCNN(B1,B2,m,n, dynamic_param,static_param)
h1=[];h2=[];hh1=[];hh2=[];B=B1;
 for i=1:2
 for j=1:4
     if i==1
         q=cell2mat(B(i,j));h1=[h1;q];
         Q=HRCNN_exam(dynamic_param,(q),static_param);hh1=[hh1;Q];%mat2gray
     end
     if i==2
         q=(cell2mat(B(i,j)));h2=[h2;q];
         Q=HRCNN_exam(dynamic_param,(q),static_param);hh2=[hh2;Q];
     end
 end
 end
H1=[];H2=[];HH1=[];HH2=[]; B=B2;
 for i=1:2
 for j=1:4
     if i==1
         q=cell2mat(B(i,j));H1=[H1;q];
         Q=HRCNN_exam(dynamic_param,(q),static_param);HH1=[HH1;Q];
     end
     if i==2
         q=(cell2mat(B(i,j)));H2=[H2;q];
         Q=HRCNN_exam(dynamic_param,(q),static_param);HH2=[HH2;Q];
     end
 end

 end
G1=newhigh(h1,H1,hh1,HH1);G2=newhigh(h2,H2,hh2,HH2);
G1=Divide_into_block(G1,m,n)';G2=Divide_into_block(G2,m,n)';
end