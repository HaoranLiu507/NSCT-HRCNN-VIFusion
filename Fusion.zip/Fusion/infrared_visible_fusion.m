function H_out = infrared_visible_fusion(low1,low2,hight1,hight2,dynamic_param,static_param,Size)
H = zeros(Size);
H(:,:,1) = (LSF(low1{1},low2{1},hight1{1},hight2{1},dynamic_param,static_param));
H(:,:,2) = (LSF(low1{2},low2{2},hight1{2},hight2{2},dynamic_param,static_param));
H(:,:,3) = (LSF(low1{3},low2{3},hight1{3},hight2{3},dynamic_param,static_param));
H_out = uint8(H);
end
