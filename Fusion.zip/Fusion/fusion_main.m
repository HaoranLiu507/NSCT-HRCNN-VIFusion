function H_out = fusion_main(im1,im2,dynamic_param,static_param)
%% The infrared image is a grayscale image
if ~isgray(im2)
    im2 = rgb2gray(im2);
end
Size = size(im1);
%% NSCT decomposed
[low1{1},low2{1},hight1{1},hight2{1}] = NSCT_data(im1(:,:,1),im2);
[low1{2},low2{2},hight1{2},hight2{2}] = NSCT_data(im1(:,:,2),im2);
[low1{3},low2{3},hight1{3},hight2{3}] = NSCT_data(im1(:,:,3),im2);
%% fusion
H=infrared_visible_fusion(low1,low2,hight1,hight2,dynamic_param,static_param,Size);
%% image enhancement
H = rgb2hsv(H);
H(:,:,3) = adapthisteq(H(:,:,3),'NumTiles',[5 ,5],'ClipLimit',0.00125,'NBins',500);
H = hsv2rgb(H);
H = im2uint8(H);
H = simple_color_balance(H);
H = gammaCorrection(H,1,1.2);
H_out = im2uint8(H);
end
