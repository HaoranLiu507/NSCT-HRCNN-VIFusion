function [W,B]=HierarchicalParam(m,n,t,B_max,B_min,a1,a2)
% This program is used to hierarchically process the images
% generate the weight matrix W and connection coefficients B of RCNN;
% m,n are the number of rows and columns of the image respectively;
% t is the number of iterations;
% B_max,B_min are the maximum and minimum values of the connection coefficient, respectively
% d_max = max(m,n)/2;
% d_max = floor(min(m,n)/3);

if(min(m,n)/2>80)
    d_max = 80;
else
    d_max = min(m,n)/4;
end

d_min = 5;
d_temp = floor((d_max - d_min)/t);
d=[];
d(1) = d_max;

% Ensure that the dimension d of the matrix W is odd for each iteration
% and decreases with each iteration;
if mod(d(1),2) == 0
   d(1) = d(1)-1;
end
for i = 2:t
    d(i) = d(i-1)-a1*d_temp;
    if d(i) < d_min
        d(i) = d_min;
    end
    if mod(d(i),2) == 0
        d(i) = d(i)-1;
    end
end
sigma = d/4 + 5;
sigma1 = sigma;
sigma2 = sigma;
% connection coefficients B decreases with each iteration;
B = [];
B(1) = B_max;
B_temp = (B_max-B_min)/t;
for  i = 2:t
    B(i) = B(i-1)-a2*B_temp;
    if B(i) < B_min
        B(i) = B_min;
    end
end
% Generate the weight matrix W;
W=cell(1,t);
for i = 1:t
    W_default=fspecial('gaussian',d(i),sigma1(i));
    W_default((d(i)+1)/2,(d(i)+1)/2)=0;
    W{1,i} = W_default.*rand_matrix(d(i),0.1,'norm',sigma2(i));
end


