%% This is an image segmentation algorithm of HRCNN 
function YY = HRCNN_exam(dynamic_param,I,static_param)
% Dynamic parameters are set automatically
aT = dynamic_param.aT;
vT = dynamic_param.vT;
aF = dynamic_param.aF;
B_max = dynamic_param.B_max;
a2 = dynamic_param.a2;

% Manual Settings are static parameters
t=static_param.T;
a1=static_param.a1;
B_min=0.01;

S = im2double(I);
[m,n]=size(S);YY=zeros(m,n);
E=YY+1;Y=YY;
U=YY;
V=1; % amplification coefficient
[W,B]=HierarchicalParam(m,n,t,B_max,B_min,a1,a2);
% Proceso iterativo
for i = 1:t            
    L = conv2(Y,W{1,i},'same');
    U = U.*exp(-aF) + S.*(1+V*B(i)*L);
    Y = im2double(U>E);             
    E = exp(-aT)*E + vT*Y;
    YY = Y+YY;
end
end
