function [I] =newhigh(I1,I2,N1,N2)
% High frequency fusion program, who takes who
[m,n]=size(I1);
I=zeros(m,n);
for i=1:m
    for j=1:n
        if N1(i,j)>=N2(i,j)
            I(i,j)=I1(i,j);
        end
        if N2(i,j)>=N1(i,j)
            I(i,j)=I2(i,j);
        end       
     end
end