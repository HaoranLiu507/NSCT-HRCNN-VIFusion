function [low1,low2,hight1,hight2] = NSCT_data(im1_VI,im2_IR)
[low1,low2,hight1,hight2] = load_NSCT(im1_VI,im2_IR);
end